<!-- detalhes_produto.php -->
<?php
include '../conexao_banco/conexao.php';

// Conexão com o banco de dados
$conn = new mysqli('localhost', 'root', '', 'troca_roupas');
$conn->set_charset('utf8mb4');


// Verifica se o ID do produto foi passado na URL
if (isset($_GET['id'])) {
    // Recupera o ID do produto da URL
    $produto_id = $_GET['id'];

    // SQL para selecionar o produto pelo ID
    $selecionar = "SELECT * FROM roupas WHERE id = ?";
    $stmt = $conn->prepare($selecionar);

    if ($stmt) {
        // Liga o valor do ID à consulta preparada
        $stmt->bind_param("i", $produto_id);

        // Executa a consulta preparada
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // Obtém os detalhes do produto
            $row = $result->fetch_assoc();
            echo "<div class='produto-detalhes'>";
            echo "<h2>" . htmlspecialchars($row["titulo"]) . "</h2>";
            echo "<p>" . htmlspecialchars($row["descricao"]) . "</p>";
            echo "<p>Modelo: " . htmlspecialchars($row["modelo"]) . "</p>";
            echo "<p>Cor: " . htmlspecialchars($row["cor"]) . "</p>";
            echo "<p>Tamanho: " . htmlspecialchars($row["tamanho"]) . "</p>";
            echo "<p>Categoria: " . htmlspecialchars($row["categoria"]) . "</p>";
            echo "<p>Estado: " . htmlspecialchars($row["estado"]) . "</p>";

            // Exibe a imagem principal
            if ($row["imagem_principal"] != NULL) {
                echo "<img src='" . htmlspecialchars($row["imagem_principal"]) . "' alt='Imagem Principal da Roupa' style='max-width: 300px;'>";
            }

            // Exibe as imagens secundárias
            if ($row["imagem_secundaria1"] != NULL) {
                echo "<img src='" . htmlspecialchars($row["imagem_secundaria1"]) . "' alt='Imagem Secundária 1 da Roupa' style='margin-right: 10px; max-width: 150px;'>";
            }
            if ($row["imagem_secundaria2"] != NULL) {
                echo "<img src='" . htmlspecialchars($row["imagem_secundaria2"]) . "' alt='Imagem Secundária 2 da Roupa' style='margin-right: 10px; max-width: 150px;'>";
            }
            if ($row["imagem_secundaria3"] != NULL) {
                echo "<img src='" . htmlspecialchars($row["imagem_secundaria3"]) . "' alt='Imagem Secundária 3 da Roupa' style='margin-right: 10px; max-width: 150px;'>";
            }

            echo "</div>";
        } else {
            echo "Produto não encontrado.";
        }

        // Fecha a declaração
        $stmt->close();
    } else {
        echo "Erro na preparação da consulta: " . $conn->error;
    }
} else {
    echo "ID do produto não fornecido.";
}
?>
