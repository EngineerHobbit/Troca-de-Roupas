<?php
// Ativando relatórios de erros para debug do MySQLi
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

// Conexão com o banco de dados
$conn = new mysqli('localhost', 'root', '', 'troca_roupas');
$conn->set_charset('utf8mb4');

// SQL para selecionar todas as roupas
$selecionar = "SELECT * FROM roupas";
$result = $conn->query($selecionar);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Produtos</title>
    <link rel="stylesheet" href="../assets/css/pages/listaProdutos.css">
</head>
<body>
    <h1>Lista de Produtos</h1>
    <?php if ($result->num_rows > 0): ?>
        <?php while ($row = $result->fetch_assoc()): ?>
            <div class="produto">
                <?php if (!empty($row["imagem_principal"])): ?>
                    <img src="<?= htmlspecialchars($row["imagem_principal"]) ?>" alt="Imagem Principal da Roupa">
                <?php else: ?>
                    <img src="default-image.jpg" alt="Imagem padrão">
                <?php endif; ?>

                <div class="produto-info">
                    <h2><?= htmlspecialchars($row["titulo"]) ?></h2>
                    <p><?= htmlspecialchars($row["descricao"]) ?></p>
                    <p><strong>Modelo:</strong> <?= htmlspecialchars($row["modelo"]) ?></p>
                    <p><strong>Cor:</strong> <?= htmlspecialchars($row["cor"]) ?></p>
                    <p><strong>Tamanho:</strong> <?= htmlspecialchars($row["tamanho"]) ?></p>
                    <p><strong>Categoria:</strong> <?= htmlspecialchars($row["categoria"]) ?></p>
                    <p><strong>Estado:</strong> <?= htmlspecialchars($row["estado"]) ?></p>
                    <a href="detalhes_produtos.php?id=<?= htmlspecialchars($row["id"]) ?>">Ver detalhes</a>
                    
                </div>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <p>Nenhum produto encontrado.</p>
    <?php endif; ?>

    <?php
    // Fecha a conexão com o banco de dados
    $conn->close();
    ?>
</body>
</html>
