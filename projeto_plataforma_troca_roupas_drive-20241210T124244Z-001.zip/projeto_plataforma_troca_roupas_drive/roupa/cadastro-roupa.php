<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar Roupa</title>
    <link rel="stylesheet" href="../assets/css/global/formularios.css">


</head>
<body>
    <div class="container">
        <div class="form-image">
            <img src="" alt="Imagem da Roupa">
        </div>
        <div class="form">
            <div class="form-header">
                <h1>Cadastrar Roupa</h1>
            </div>
            <form action="../conexao_banco/conexao_roupa.php" method="POST" enctype="multipart/form-data">
                <div class="input-group">
                    <div class="input-box">
                        <label for="titulo">Título</label>
                        <input type="text" name="titulo" id="titulo" placeholder="Nome da peça" required>
                    </div>
                    <div class="input-box">
                        <label for="descricao">Descrição</label>
                        <input type="text" name="descricao" id="descricao" placeholder="Descrição" required>
                    </div>
                    <div class="input-box">
                        <label for="modelo">Modelo</label>
                        <select id="modelo" name="modelo">
                            <option value="">Selecione o modelo</option>
                            <option value="camiseta">Camiseta</option>
                            <option value="calca-jeans">Calça Jeans</option>
                            <option value="vestido">Vestido</option>
                            <option value="blusa">Blusa</option>
                            <option value="shorts">Shorts</option>
                            <option value="saia">Saia</option>
                            <option value="casaco">Casaco</option>
                            <option value="macacao">Macacão</option>
                            <option value="camisa">Camisa</option>
                            <option value="jaqueta">Jaqueta</option>
                            <option value="biquini">Biquíni</option>
                            <option value="maio">Maiô</option>
                        </select>
                    </div>
                    <div class="input-box">
                        <label for="cor">Cor</label>
                        <select id="cor" name="cor">
                            <option value="">Selecione uma cor</option>
                            <option value="red">Vermelho</option>
                            <option value="green">Verde</option>
                            <option value="blue">Azul</option>
                            <option value="yellow">Amarelo</option>
                            <option value="black">Preto</option>
                            <option value="white">Branco</option>
                            <option value="orange">Laranja</option>
                            <option value="purple">Roxo</option>
                            <option value="pink">Rosa</option>
                            <option value="brown">Marrom</option>
                            <option value="cyan">Ciano</option>
                            <option value="magenta">Magenta</option>
                        </select>
                    </div>
                    <div class="input-box">
                        <label for="tamanho">Tamanho:</label>
                        <select name="tamanho" id="tamanho" required>
                            <option value="">Selecione o tamanho</option>
                            <option value="P">P</option>
                            <option value="M">M</option>
                            <option value="G">G</option>
                            <option value="GG">GG</option>
                            <option value="XGG">XGG</option>
                        </select>
                    </div>
                    <div class="input-box">
                        <label for="categoria">Categoria:</label>
                        <select id="categoria" name="categoria">
                            <option value="">Selecione uma categoria</option>
                            <option value="masculino">Masculino</option>
                            <option value="feminino">Feminino</option>
                            <option value="infantil">Infantil</option>
                            <option value="esporte">Esporte</option>
                            <option value="social">Social</option>
                            <option value="casual">Casual</option>
                            <option value="praia">Praia</option>
                            <option value="inverno">Inverno</option>
                            <option value="verao">Verão</option>
                            <option value="fitness">Fitness</option>
                            <option value="plus-size">Plus Size</option>
                            <option value="acessorios">Acessórios</option>
                        </select>
                    </div>
                    <div class="input-box">
                        <label for="estado">Estado da peça:</label>
                        <select id="estado" name="estado">
                            <option value="">Selecione uma opção</option>
                            <option value="novo">Novo</option>
                            <option value="semi-novo">Semi-novo</option>
                            <option value="usado">Usado</option>
                            <option value="otimo-estado">Ótimo estado</option>
                            <option value="defeitos">Com pequenos defeitos</option>
                        </select>
                    </div>
                    <div class="input-box">
                        <label for="foto">Fotos da Roupa:</label>
                        <input type="file" name="imagens[]" id="foto" accept="image/*" multiple required>
                    </div>
                </div>
                <div class="continue-button">
                    <button type="submit">Cadastrar</button>
                </div>
                <div class="continue-button">
                    <button type="button"><a href="../index.php">Voltar</a></button>
                </div>
                </div>

            </form>
        </div>
    </div>
</body>


</html>