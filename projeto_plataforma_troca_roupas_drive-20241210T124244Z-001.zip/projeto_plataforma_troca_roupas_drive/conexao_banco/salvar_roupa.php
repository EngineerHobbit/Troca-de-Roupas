<?php
include 'conexao.php';

// Receber dados do formulário
$nome_produto = $_POST['titulo'];
$descricao = $_POST['descricao'];
$modelo = $_POST['modelo'];
$tamanho = $_POST['tamanho'];
$cor = isset($_POST['cor']) ? $_POST['cor'] : 'valor_padrao_ou_null';
$categoria = isset($_POST['categoria']) ? $_POST['categoria'] : 'valor_padrao_ou_null';
$estado = isset($_POST['estado']) ? $_POST['estado'] : 'valor_padrao_ou_null';

// Upload das fotos
if (isset($_FILES['imagens']) && is_array($_FILES['imagens']['name']) && count($_FILES['imagens']['name']) > 0) {

    $diretorio = "./uploads/"; // Definindo o diretório de uploads
    if (!is_dir($diretorio)) {
        mkdir($diretorio, 0755, true);
    }

    $nomes_fotos = array();
    foreach ($_FILES['imagens']['name'] as $key => $nomeImagem) {
        $nomeTemporario = $_FILES['imagens']['tmp_name'][$key];
        $nomeUnico = time() . "_" . basename($nomeImagem);
        $caminhoFinal = $diretorio . $nomeUnico;

        if (move_uploaded_file($nomeTemporario, $caminhoFinal)) {
            $nomes_fotos[] = $nomeUnico; // Salva apenas o nome do arquivo, não o caminho completo
        } else {
            echo "Erro ao fazer upload da foto: " . $nomeImagem;
        }
    }

    // Serializar os nomes das fotos para salvar no banco
    $fotos_serializadas = implode(",", $nomes_fotos);

    // Preparar a inserção das roupas
    $stmtRoupa = $pdo->prepare("INSERT INTO roupas (titulo, descricao, modelo, tamanho, cor, categoria, estado, fotos)
                             VALUES (:titulo, :descricao, :modelo, :tamanho, :cor, :categoria, :estado, :fotos)");
    $stmtRoupa->bindParam(':titulo', $nome_produto);
    $stmtRoupa->bindParam(':descricao', $descricao);
    $stmtRoupa->bindParam(':modelo', $modelo);
    $stmtRoupa->bindParam(':tamanho', $tamanho);
    $stmtRoupa->bindParam(':cor', $cor);
    $stmtRoupa->bindParam(':categoria', $categoria);
    $stmtRoupa->bindParam(':estado', $estado);
    $stmtRoupa->bindParam(':fotos', $fotos_serializadas);

    // Executar a inserção das roupas
    $stmtRoupa->execute();

    // Obter o ID da roupa inserida
    $ultimoId = $pdo->lastInsertId();

    // Preparar a inserção das imagens
    foreach ($nomes_fotos as $nomeFoto) {
        $stmtImagem = $pdo->prepare("INSERT INTO imagens (nome_imagem, roupa_id) VALUES (:nome_imagem, :roupa_id)");
        $stmtImagem->bindParam(':nome_imagem', $nomeFoto);
        $stmtImagem->bindParam(':roupa_id', $ultimoId);
        $stmtImagem->execute();
    }
}
?>
