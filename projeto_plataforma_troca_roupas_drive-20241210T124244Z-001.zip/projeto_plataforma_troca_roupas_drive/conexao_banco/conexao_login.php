<?php  
session_start();
include('conexao.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $senha = $_POST['password']; // Change this line to match the form field name

    if (isset($email) && isset($senha)) {
        // Preparação da consulta para evitar injeção de SQL
        $query = $conn->prepare("SELECT * FROM login WHERE email = ?");
        
        // Verificar se a preparação da consulta foi bem-sucedida
        if ($query) {
            $query->bind_param("s", $email);
            $query->execute();
            $result = $query->get_result();
            $user = $result->fetch_assoc();

            if ($user && password_verify($senha, $user['senha'])) { // Correct field to check password
                // Login bem-sucedido
                $_SESSION['email'] = $email;

                header('Location: ../index.php');
                exit();
            } else {
                $_SESSION['senha'] != $senha;
                header('Location: ../login.php');



                echo "Erro ao fazer login. E-mail ou senha inválidos.";
            }
        } else {
            // Exibir erro da consulta SQL
            echo "Erro 1 na preparação da consulta: " . $conn->error;
        }
    }
}
?>
