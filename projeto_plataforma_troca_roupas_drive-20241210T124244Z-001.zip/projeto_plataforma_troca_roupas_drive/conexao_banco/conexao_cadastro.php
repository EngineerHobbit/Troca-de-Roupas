<?php
include 'conexao.php'; // Certifique-se de que este arquivo retorna uma conexão mysqli

// Receber dados do formulário
$nome_produto = mysqli_real_escape_string($conn, $_POST['titulo']);
$descricao = mysqli_real_escape_string($conn, $_POST['descricao']);
$modelo = mysqli_real_escape_string($conn, $_POST['modelo']);
$tamanho = mysqli_real_escape_string($conn, $_POST['tamanho']);
$cor = isset($_POST['cor']) ? mysqli_real_escape_string($conn, $_POST['cor']) : 'valor_padrao_ou_null';
$categoria = isset($_POST['categoria']) ? mysqli_real_escape_string($conn, $_POST['categoria']) : 'valor_padrao_ou_null';
$estado = isset($_POST['estado']) ? mysqli_real_escape_string($conn, $_POST['estado']) : 'valor_padrao_ou_null';

// Upload das fotos
if (isset($_FILES['imagens']) && is_array($_FILES['imagens']['name']) && count($_FILES['imagens']['name']) > 0) {

    $diretorio = "./uploads/"; // Definindo o diretório de uploads
    if (!is_dir($diretorio)) {
        mkdir($diretorio, 0755, true);
    }

    $nomes_fotos = array();
    foreach ($_FILES['imagens']['name'] as $key => $nomeImagem) {
        $nomeTemporario = $_FILES['imagens']['tmp_name'][$key];
        $nomeUnico = time() . "_" . basename($nomeImagem);
        $caminhoFinal = $diretorio . $nomeUnico;

        if (move_uploaded_file($nomeTemporario, $caminhoFinal)) {
            $nomes_fotos[] = $nomeUnico; // Salva apenas o nome do arquivo, não o caminho completo
        } else {
            echo "Erro ao fazer upload da foto: " . $nomeImagem;
        }
    }

    // Serializar os nomes das fotos para salvar no banco
    $fotos_serializadas = implode(",", $nomes_fotos);

    // Preparar a inserção das roupas
    $sqlRoupa = "INSERT INTO roupas (titulo, descricao, modelo, tamanho, cor, categoria, estado, fotos)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmtRoupa = $conn->prepare($sqlRoupa);
    $stmtRoupa->bind_param("ssssssss", $nome_produto, $descricao, $modelo, $tamanho, $cor, $categoria, $estado, $fotos_serializadas);

    // Executar a inserção das roupas
    if ($stmtRoupa->execute()) {
        echo "Roupa inserida com sucesso.";
        
        // Obter o ID da roupa inserida
        $ultimoId = $conn->insert_id;

        // Preparar a inserção das imagens
        foreach ($nomes_fotos as $nomeFoto) {
            $sqlImagem = "INSERT INTO imagens (nome_imagem, roupa_id) VALUES (?, ?)";
            $stmtImagem = $conn->prepare($sqlImagem);
            $stmtImagem->bind_param("is", $nomeFoto, $ultimoId);
            $stmtImagem->execute();
        }
    } else {
        echo "Erro ao inserir roupa: " . $stmtRoupa->error;
    }
}
?>
