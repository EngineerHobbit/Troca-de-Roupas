<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $servername = "127.0.0.1";
    $username = "root";
    $password = "";
    $dbname = "troca_roupas";
    
    // Cria a conexão com o banco de dados
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    
    // Verifica a conexão
    if (!$conn) {
        die("Conexão falhou: " . mysqli_connect_error());
    }
    
    // Criar o banco de dados se não existir
    $sql = "CREATE DATABASE IF NOT EXISTS troca_roupas";
    if (mysqli_query($conn, $sql)) {
        echo "Banco de dados criado ou já existe.<br>";
    } else {
        die("Erro ao criar o banco de dados: " . mysqli_error($conn));
    }

    // Selecionar o banco de dados
    mysqli_select_db($conn, $dbname);

    // Criar a tabela se não existir
    $sqlUsuario = "CREATE TABLE IF NOT EXISTS usuarios (
        id INT AUTO_INCREMENT PRIMARY KEY,
        primeiro_nome VARCHAR(50) NOT NULL,
        sobrenome VARCHAR(50) NOT NULL,
        cpf VARCHAR(14) UNIQUE NOT NULL,
        email VARCHAR(100) NOT NULL,
        celular VARCHAR(15) NOT NULL,
        genero VARCHAR(20) NOT NULL,
        senha VARCHAR(255) NOT NULL,
        data_nascimento DATE NOT NULL,
        cep VARCHAR(9) NOT NULL,
        estado VARCHAR(2) NOT NULL,
        cidade VARCHAR(50) NOT NULL,
        rua VARCHAR(100) NOT NULL,
        numero VARCHAR(10) NOT NULL,
        bairro VARCHAR(50) NOT NULL,
        complemento VARCHAR(100))";
        
    if (mysqli_query($conn, $sqlUsuario)) {
        echo "Tabela criada com sucesso.<br>";
    } else {
        die("Erro ao criar a tabela: " . mysqli_error($conn));
    }

    $sqlLogin = "CREATE TABLE IF NOT EXISTS login (
        id INT AUTO_INCREMENT PRIMARY KEY,
        email VARCHAR(100) NOT NULL,
        senha VARCHAR(255) NOT NULL,
        usuario_id INT NOT NULL,
        FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE ON UPDATE CASCADE,
        UNIQUE(email))";

    if (mysqli_query($conn, $sqlLogin)) {
        echo "Tabela 'login' criada com sucesso.<br>";
    } else {
        die("Erro ao criar a tabela 'login': " . mysqli_error($conn));
    } 

    $sqlRoupas = "CREATE TABLE IF NOT EXISTS roupas (
        roupa_id INT AUTO_INCREMENT PRIMARY KEY,
        titulo VARCHAR(255) NOT NULL,
        descricao TEXT,
        modelo VARCHAR(50),
        cor VARCHAR(50),
        tamanho VARCHAR(10),
        categoria VARCHAR(50),
        estado VARCHAR(50),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)";
    
    if (mysqli_query($conn, $sqlRoupas)) {
        echo "Tabela 'roupas' criada com sucesso.<br>";
    } else {
        die("Erro ao criar a tabela 'roupas': " . mysqli_error($conn));
    }
    $sqlImagens = "CREATE TABLE IF NOT EXISTS `imagens` (
        `id` int NOT NULL AUTO_INCREMENT,
        `nome_imagem` varchar(220) NOT NULL,
        `roupa_id` int NOT NULL,
        FOREIGN KEY (roupa_id) REFERENCES roupas(roupa_id) ON DELETE CASCADE ON UPDATE CASCADE,
        PRIMARY KEY (`id`)
      )";
        
    if (mysqli_query($conn, $sqlImagens)) {
        echo "Tabela 'imagens' criada com sucesso.<br>";
    } else {
        die("Erro ao criar a tabela 'imagens': " . mysqli_error($conn));
    }


}

?>

