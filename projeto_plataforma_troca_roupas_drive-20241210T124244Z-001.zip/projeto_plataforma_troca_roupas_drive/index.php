<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página Inicial - Troca de Roupas</title>
    <link rel="stylesheet" href="./assets/css/global/global.css">
    <link rel="stylesheet" href="./assets/css/pages/apresentacao.css">

</head>

<body>
    <header>
    <div class="botao-menu" onclick="abrirFecharMenu()">
            <span class="texto-botao">☰ Menu</span>
        </div>
        <div class="menu-lateral" id="menu-lateral">
            <ul>
                <li><a href="cadastro.php">cadastro</a></li>
                <li><a href="perfil.php">Perfil</a></li>
                <li><a href="busca-roupas.php">Procurar roupas</a></li>
                <li><a href="roupa/cadastro-roupa.php">Cadastrar roupas</a></li>
                <li><a href="favoritos.php">Favoritos</a></li>
                <li><a href="minhas-roupas.php">Minhas roupas</a></li>
                <li><a href="notificacoes.php">Notificações</a></li>
                <li><a href="sobre-nos.php">Sobre</a></li>
                <li><a href="contato.php">Contato</a></li>
                <li><a href="relatorios.php">Histórico</a></li>
                <li><a href="propostas.php">Propostas</a></li>
                <li><a href="../conexao_banco/conexao.php"></a>conexao</li>
                <li><a href="roupa/exibir_produtos.php">exibr roupa</a></li>

                <li><a href="roupa/detalhes_produtos.php">detalhes</a></li>


                <li>
                    <div class="botao-fechar" onclick="abrirFecharMenu()">
                        <span class="texto-botao-fechar"> X Fechar</span>
                    </div>
                </li>
            </ul>
        </div>
        <script>
            function abrirFecharMenu() {
                var menuLateral = document.getElementById('menu-lateral');
                if (menuLateral.classList.contains('aberto')) {
                    menuLateral.classList.remove('aberto');
                } else {
                    menuLateral.classList.add('aberto');
                }
            }
            // Fecha o menu se o usuário clicar fora dele
            document.addEventListener('click', function (event) {
                var menuLateral = document.getElementById('menu-lateral');
                var botaoMenu = document.querySelector('.botao-menu');
                // Verifica se o clique foi fora do menu e do botão de abrir/fechar
                if (!menuLateral.contains(event.target) && !botaoMenu.contains(event.target)) {
                    menuLateral.classList.remove('aberto');
                }
            });
        </script>
        <div class="content">
            
            <h1>Troca Comigo</h1>
            <nav>
                <a href="index.php">Início</a>
                <a href="sobre-nos.php">Sobre Nós</a>
                <a href="login.php">Login</a>
                <a href="contato.php">Contato</a>
                <a href="ajuda.php">Ajuda</a>
            </nav>
        </div>

        <div class="search-bar">
            <input type="text" placeholder="Buscar roupas, categorias ou usuários...">
            <button>Pesquisar</button>
        </div>
    </header>
    <div class="rolagem">
    <main>
        <div class="principal">
        <div class="banner">
        <div>
            <h1>Troque Roupas, Economize e Ajude o Planeta!</h1>
            <p>Descubra como economizar e compartilhar com a nossa comunidade.</p>
            <div class="cta-buttons">
                <a href="cadastro.php">Cadastre-se Agora</a>
                <a href="busca-roupas.php">Veja as Roupas Disponíveis</a>
            </div>
        </div>
    </div>

    <section class="benefits">
        <h2>Por que usar nossa plataforma?</h2>
        <div class="items">
            <div class="item">
                <h3>Economize</h3>
                <p>Reduza seus gastos com roupas trocando peças.</p>
            </div>
            <div class="item">
                <h3>Sustentabilidade</h3>
                <p>Ajude o meio ambiente diminuindo o desperdício.</p>
            </div>
            <div class="item">
                <h3>Conexão</h3>
                <p>Faça parte de uma comunidade que compartilha.</p>
            </div>
        </div>
    </section>

    <section class="testimonials">
        <h2>Histórias de Sucesso</h2>
        <div class="items">
            <div class="item">
                <p>"Troquei um vestido que não usava mais por uma jaqueta incrível!"</p>
                <p>- Ana</p>
            </div>
            <div class="item">
                <p>"Adorei a experiência, é muito simples e prático."</p>
                <p>- João</p>
            </div>
        </div>
    </section>

        </div>
    </main>

    <footer>
        <p>&copy; 2024 Troca de Roupas. Todos os direitos reservados.</p>
        <nav>
            <a href="/politicas">Políticas de Privacidade</a>
            <a href="/termos">Termos de Uso</a>
            <a href="/contato">Contato</a>
        </nav>
    </footer>
    </div>

</body>

</html>