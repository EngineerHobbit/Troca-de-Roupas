<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/global/formularios.css">
]    <title>Formulário</title>
</head>
<body>
    <div class="container">
        <div class="form-image">
            <img src="assets/img//undraw_shopping_re_3wst.svg" alt="">
        </div>
        <div class="form">
            <table>
                <td>
                    <h1>Cadastre-se</h1>
                </td>
                <td>
                    <div class="continue-button">
                        <button type="button" onclick="window.location.href='login.php'">Entrar</button>
                    </div>
                </td>
            </table>
            <form action="conexao_banco/conexao_cadastro.php" method="post" autocomplete="on">
                <div class="form-header">
                    <div class="title">
                        <div class="input-box">
                            <label for="firstname">Primeiro nome:</label>
                            <input type="text" name="firstname" id="primeiro" placeholder="Digite o seu nome" required>
                        </div>
                        <div class="input-box">
                            <label for="lastname">Sobrenome:</label>
                            <input type="text" name="lastname" id="lastname" placeholder="Digite o seu sobrenome"
                                required>
                        </div>
                        <div class="input-box">
                            <label for="cpf">CPF:</label>
                            <input type="text" name="cpf" id="cpf" pattern="\d{3}\.\d{3}\.\d{3}-\d{2}"
                                placeholder="000.000.000-00" required>
                        </div>
                        <div class="input-box">
                            <label for="email">E-mail:</label>
                            <input type="text" name="email" id="email" placeholder="Digite o seu E-mail"
                                autocomplete="on" required>
                        </div>
                        <div class="input-box">
                            <label for="number">Celular:</label>
                            <input id="number" type="tel" name="number" placeholder="(xx) xxxx-xxxx" required>
                        </div>
                        <div class="input-box">
                            <label for="genero">Gênero:</label> <br>
                            <select name="genero" id="genero" required>
                                <option value=" "> </option>
                                <option value="homem">Homem</option>
                                <option value="mulher">Mulher</option>
                                <option value="outros">Outros</option>
                                <option value="nao-especificado">Não especificado</option>
                            </select> <br>
                        </div>
                        <div class="input-box">
                            <label for="password">Senha:</label>
                            <input id="password" type="password" name="password" placeholder="Digite sua senha"
                                required>
                        </div>
                        <div class="input-box">
                            <label for="confirmPassword">Confirme sua Senha:</label>
                            <input id="confirmPassword" type="password" name="confirmPassword"
                                placeholder="Digite sua senha novamente" required>
                        </div>
                        <div class="input-box">
                            <label for="data_de_Nascimento">Data de nascimento:</label> <br>
                            <input type="date" name="data_de_Nascimento" id="data_de_Nascimento" required> <br><br>
                        </div>
                        <div class="input-box">
                            <tr>
                                <td>
                                    <label for="cep">CEP: </label>
                                </td>
                                <td class="endereco-box">
                                    <input type="text" name="cep" id="cep" pattern="\d{5}-\d{3}" placeholder="00000-000"
                                        required>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label for="estado">Estado:</label>
                                </td>
                                <td class="endereco-box">
                                    <select name="estado" id="estado">
                                        <option value="">Selecione</option>
                                        <option value="AC">Acre</option>
                                        <option value="AL">Alagoas</option>
                                        <option value="AM">Amazonas</option>
                                        <option value="AP">Amapá</option>
                                        <option value="BA">Bahia</option>
                                        <option value="CE">Ceará</option>
                                        <option value="DF">Distrito Federal</option>
                                        <option value="ES">Espírito Santo</option>
                                        <option value="GO">Goiás</option>
                                        <option value="MA">Maranhão</option>
                                        <option value="MT">Mato Grosso</option>
                                        <option value="MS">Mato Grosso do Sul</option>
                                        <option value="MG">Minas Gerais</option>
                                        <option value="PA">Pará</option>
                                        <option value="PB">Paraíba</option>
                                        <option value="PR">Paraná</option>
                                        <option value="PE">Pernambuco</option>
                                        <option value="PI">Piauí</option>
                                        <option value="RJ">Rio de Janeiro</option>
                                        <option value="RN">Rio Grande do Norte</option>
                                        <option value="RO">Rondônia</option>
                                        <option value="RS">Rio Grande do Sul</option>
                                        <option value="RR">Roraima</option>
                                        <option value="SC">Santa Catarina</option>
                                        <option value="SE">Sergipe</option>
                                        <option value="SP">São Paulo</option>
                                        <option value="TO">Tocantins</option>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label for="cidade">Cidade: </label>
                                </td>
                                <td class="endereco-box">
                                    <input type="text" name="cidade" id="cidade" readonly>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label for="rua">Rua:</label>
                                </td>
                                <td class="endereco-box">
                                    <input type="text" name="rua" id="rua" required>
                                </td>
                                <td>
                                    <label for="numero">Número:</label>
                                </td>
                                <td class="endereco-box">
                                    <input type="text" name="numero" size="6" required>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label for="bairro">Bairro: </label>
                                </td>
                                <td class="endereco-box">
                                    <input type="text" name="bairro" id="bairro" required>
                                </td>
                                <td>
                                    <label for="Complemento">Complemento: </label>
                                </td>
                                <td class="endereco-box">
                                    <input type="text" name="complemento" id="complemento" required>
                                </td>
                            </tr>
                            </table>

                        </div>
                        <div class="continue-button">
                            <button type="submit">Cadastrar</button>
                        </div>
                        <div class="continue-button">
                            <button type="button" onclick="window.location.href='index.php'">Voltar</button>
                        </div>
                        <a href="login.php">Já é cadastrado? <strong>Clique aqui!</strong></a>



                        <script>
                            const inputNumber = document.getElementById('number');
                            inputNumber.addEventListener('input', function (e) {
                                let value = e.target.value.replace(/\D/g, '');
                                if (value.length > 2) value = `(${value.slice(0, 2)}) ${value.slice(2)}`;
                                if (value.length > 9) value = `${value.slice(0, 9)}-${value.slice(9, 13)}`;
                                e.target.value = value;
                            });
                            const inputCPF = document.getElementById('cpf');
                            inputCPF.addEventListener('input', function (e) {
                                let value = e.target.value.replace(/\D/g, ''); // Remove caracteres não numéricos
                                if (value.length > 3) value = `${value.slice(0, 3)}.${value.slice(3)}`;
                                if (value.length > 6) value = `${value.slice(0, 7)}.${value.slice(7)}`;
                                if (value.length > 9) value = `${value.slice(0, 11)}-${value.slice(11, 13)}`;
                                e.target.value = value;
                            });
                            const inputCEP = document.getElementById('cep');
                            inputCEP.addEventListener('input', function (e) {
                                let value = e.target.value.replace(/\D/g, ''); // Remove caracteres não numéricos
                                if (value.length > 5) value = `${value.slice(0, 5)}-${value.slice(5, 8)}`; // Formata como XXXXX-XXX
                                e.target.value = value;
                            });
                            inputCEP.addEventListener('blur', function () {
                                const cep = this.value.replace(/\D/g, ''); // Remove caracteres não numéricos
                                if (cep.length === 8) {
                                    fetch(`https://viacep.com.br/ws/${cep}/json/`)
                                        .then(response => response.json())
                                        .then(data => {
                                            if (!data.erro) {
                                                document.getElementById('estado').value = data.uf; // Preenche o estado
                                                document.getElementById('cidade').value = data.localidade; // Preenche a cidade
                                                document.getElementById('bairro').value = data.bairro; // Preenche o bairro
                                                document.getElementById('rua').value = data.logradouro; // Preenche a rua
                                            } else {
                                                alert('CEP não encontrado!');
                                            }
                                        })
                                        .catch(() => alert('Erro ao buscar o CEP!'));
                                } else {
                                    alert('CEP inválido! Digite um CEP com 8 dígitos.');
                                }
                            });
                        </script>
            </form>
        </div>
    </div>
    <?php if (!empty($errors)): ?>
        <ul style="color: red;">
            <?php foreach ($errors as $error): ?>
                <li><?php echo $error; ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>



</body>

</html>