<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="./assets/css/global/formularios.css">
    <link rel="stylesheet" href="assets/css/global/global.css">
</head>
<body>
<div class="container">
    <div class="form-image">
        <img src="assets/img/undraw_shopping_re_3wst.svg" alt="">
    </div>
    <div class="form">
        <h1>Login</h1>
        <form action="conexao_banco/conexao_login.php" method="post">
            <div class="input-box">
                <label for="email">E-mail</label>
                <input type="text" id="email" name="email" required> <br>
                <label for="password">Senha:</label>
                <input type="password" id="password" name="password" required> <br>
                <?php if (isset($erro)) echo "<p style='color:red;'>$erro</p>"; ?>
                <div class="continue-button">
                    <button type="index.php">Entrar</button>
                </div>
                <div class="continue-button">
                    <button type="button" onclick="window.location.href='index.php'">Voltar</button>
                </div>
                <a href="cadastro.php">Ainda não é cadastrado? <strong>Clique aqui!</strong></a>
            </div>
        </form>
    </div>
</div>
</body>
</html>




